import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:reel_et_story/data/test_data.dart';
import 'package:reel_et_story/view/reel/reel_view.dart';
import 'package:reel_et_story/view/story/cube_effect.dart';
import 'package:reel_et_story/view/story/story_view.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData.dark(
        useMaterial3: true
      ),
      debugShowCheckedModeBanner: false,
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("UI Reel & Stories"),),
      body: Column(
        children: [
          SizedBox(
            height: 60,
            child: ListView.builder(
              itemCount: users.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  return InkWell(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.grey,
                        backgroundImage: CachedNetworkImageProvider(users[index].imageUrl),
                      ),
                    ),
                    onTap: () {
                      final route = MaterialPageRoute(
                          builder: (context) {
                            return StoryView(index: index, callback: toNextStory);
                          }
                      );
                      Navigator.push(context, route);
                    },
                  );
                }
            ),
          ),
          const Divider(),
          const Expanded(
              child: ReelView()
          )
        ],
      ),
    );
  }

  toNextStory(int index, Widget currentWidget) {
    final Widget nextWidget = StoryView(index: index, callback: toNextStory);
    final route = CubeEffect(currentWidget: widget, nextWidget: nextWidget);
    Navigator.of(context).pushReplacement(route);
  }
}
