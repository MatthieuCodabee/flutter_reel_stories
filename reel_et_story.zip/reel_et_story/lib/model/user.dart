import 'package:reel_et_story/model/story.dart';

class User {

  final String username;
  final String imageUrl;
  final List<Story> stories;

  User({
    required this.username,
    required this.imageUrl,
    required this.stories
    });
}