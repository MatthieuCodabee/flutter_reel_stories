import 'media_type.dart';

class Story {
  final String url;
  final Duration duration;
  final MediaType type;

  Story({
    required this.url,
    required this.type,
    required this.duration
  });
}