enum MediaType {
  image, video
}