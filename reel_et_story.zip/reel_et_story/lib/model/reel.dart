import 'package:reel_et_story/model/media_type.dart';
import 'package:reel_et_story/model/user.dart';

class Reel {
  final String url;
  final MediaType type;
  final Duration duration;
  final User user;

  Reel({
    required this.url,
    required this.type,
    required this.duration,
    required this.user
  });
}