import 'package:flutter/material.dart';
import 'package:reel_et_story/model/media_type.dart';
import 'package:reel_et_story/view/story/image_widget.dart';
import 'package:reel_et_story/view/story/nothing_widget.dart';
import 'package:reel_et_story/view/story/video_widget.dart';
import 'package:video_player/video_player.dart';

import '../../model/story.dart';

class StoryBuilder extends StatelessWidget {
  final PageController pageController;
  final List<Story> stories;
  final VideoPlayerController? videoPlayerController;

  const StoryBuilder({
    super.key,
    required this.pageController,
    required this.stories,
    required this.videoPlayerController
  });

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      controller: pageController,
        itemCount: stories.length,
        physics: const NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          final Story story = stories[index];
          switch (story.type) {
            case MediaType.image: return ImageWidget(story: story);
            case MediaType.video: return VideoWidget(videoPlayerController: videoPlayerController);
            default: return const NothingWidget();
          }
    });
  }
}