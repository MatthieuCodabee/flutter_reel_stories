import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:reel_et_story/model/user.dart';

class UserInfos extends StatelessWidget {
  final User user;
  const UserInfos({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(
          radius: 20,
          backgroundColor: Colors.grey,
          backgroundImage: CachedNetworkImageProvider(user.imageUrl),
        ),
        const SizedBox(width: 16),
        Expanded(child: Text(user.username)),
        IconButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            icon: const Icon(Icons.close)
        )
      ],
    );
  }
}