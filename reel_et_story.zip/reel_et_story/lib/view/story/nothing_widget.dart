import 'package:flutter/material.dart';

class NothingWidget extends StatelessWidget {
  const NothingWidget({super.key});
  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}