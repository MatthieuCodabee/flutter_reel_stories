import 'package:flutter/material.dart';
import 'package:reel_et_story/view/story/nothing_widget.dart';
import 'package:video_player/video_player.dart';

class VideoWidget extends StatelessWidget {
  final VideoPlayerController? videoPlayerController;

  const VideoWidget({super.key, required this.videoPlayerController});

  @override
  Widget build(BuildContext context) {
    return (videoPlayerController != null && videoPlayerController!.value.isInitialized)
        ? FittedBox(
      fit: BoxFit.cover,
      child: SizedBox(
        width: videoPlayerController!.value.size.width,
        height: videoPlayerController!.value.size.height,
        child: VideoPlayer(videoPlayerController!),
      ),
    )
        : const NothingWidget();
  }
}