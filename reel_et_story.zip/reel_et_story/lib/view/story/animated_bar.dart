import 'package:flutter/material.dart';

class AnimatedBar extends StatelessWidget {
  final int position;
  final int index;
  final AnimationController animationController;

  const AnimatedBar({
    super.key,
    required this.position,
    required this.index,
    required this.animationController
  });

  @override
  Widget build(BuildContext context) {
    return Flexible(
        child: Padding(
          padding: const EdgeInsets.all(4),
          child: LayoutBuilder(
            builder: (context, constraints) {
              return Stack(
                children: [bar()],
              );
            },
          ),
        )
    );
  }

  Widget bar() {
    if (position == index) {
      return LinearProgressIndicator(value: animationController.value);
    } else {
      return Container(
        height: 3,
        color: (position < index) ? Colors.white : Colors.black12,
      );
    }
  }
}