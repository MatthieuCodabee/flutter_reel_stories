import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:reel_et_story/model/story.dart';

class ImageWidget extends StatelessWidget {
  final Story story;

  const ImageWidget({super.key, required this.story});

  @override
  Widget build(BuildContext context) => CachedNetworkImage(
    imageUrl: story.url,
    fit: BoxFit.cover,
  );
}