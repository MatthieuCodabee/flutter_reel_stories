import 'package:flutter/material.dart';
import 'package:reel_et_story/data/test_data.dart';
import 'package:reel_et_story/model/media_type.dart';
import 'package:reel_et_story/model/story.dart';
import 'package:reel_et_story/view/story/animated_row.dart';
import 'package:reel_et_story/view/story/stroy_builder.dart';
import 'package:reel_et_story/view/story/user_infos.dart';
import 'package:video_player/video_player.dart';

import '../../model/user.dart';

class StoryView extends StatefulWidget {
  final int index;
  final Function(int index, Widget currentWidget) callback;

  const StoryView({
   super.key,
   required this.index,
   required this.callback
  });

  @override
  StoryViewState createState() => StoryViewState();

}

class StoryViewState extends State<StoryView>  with SingleTickerProviderStateMixin {
  late PageController pageController;
  late AnimationController animationController;
  VideoPlayerController? videoPlayerController;
  int currentIndex = 0;
  late int currentUser;
  late User user;

  @override
  void initState() {
    super.initState();
    currentUser = widget.index;
    pageController = PageController();
    animationController = AnimationController(vsync: this);
    user = users[currentUser];
    final Story story = user.stories.first;
    loadStory(story: story, playAnimation: false);
    animationController.addListener(() {setState(() {});});
    animationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        animationController.stop();
        animationController.reset();
        setState(() {
          if (currentIndex + 1 < user.stories.length) {
            currentIndex += 1;
            loadStory(story: user.stories[currentIndex], playAnimation: true);
          } else {
            toNext();
          }
        });
      }
    });
  }

  @override
  void dispose() {
    pageController.dispose();
    animationController.dispose();
    videoPlayerController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Story story = user.stories[currentIndex];
    return Scaffold(
      body: GestureDetector(
        onTapDown: (tap) => onTapDown(tap, story),
        child: Stack(
          children: [
            StoryBuilder(
                pageController: pageController,
                stories: user.stories,
                videoPlayerController: videoPlayerController
            ),
            SafeArea(
                child: Column(
                  children: [
                    //AnimatedBar
                    AnimatedRow(
                        animationController: animationController,
                        stories: user.stories,
                        index: currentIndex
                    ),
                    //UserInfos
                    Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 10
                        ),
                      child: UserInfos(user: user),
                    )
                  ],
                )
            )
          ],
        ),
      ),
    );
  }

  loadStory({required Story story, required bool playAnimation}) {
    animationController.stop();
    animationController.reset();
    videoPlayerController = null;
    videoPlayerController?.dispose();
    switch (story.type) {
      case MediaType.image:
        animationController.duration = story.duration;
        animationController.forward();
        break;
      case MediaType.video:
        videoPlayerController = null;
        videoPlayerController?.dispose();
        videoPlayerController = VideoPlayerController.networkUrl(Uri.parse(story.url))
        ..initialize().then((value) => setState(() {
          if (videoPlayerController != null && videoPlayerController!.value.isInitialized) {
            animationController.duration = videoPlayerController!.value.duration;
            videoPlayerController!.play();
            animationController.forward();
          }
        }));
        break;
    }
    if (playAnimation) {
      pageController.animateToPage(
          currentIndex,
          duration: const Duration(milliseconds: 5),
          curve: Curves.easeInOut
      );
    }
  }

  onTapDown(TapDownDetails details, Story story) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double tapPosition = details.globalPosition.dx;
    if (tapPosition < screenWidth / 2) {
      setState(() {
        if (currentIndex > 0) {
          currentIndex -= 1;
          loadStory(story: user.stories[currentIndex], playAnimation: true);
        }
      });
    } else {
      setState(() {
        if (currentIndex < user.stories.length - 1) {
          currentIndex +=1;
          loadStory(story: user.stories[currentIndex], playAnimation: true);
        } else {
          toNext();
        }
      });
    }
  }

  toNext() {
    if (currentUser < users.length - 1) {
      widget.callback(currentUser + 1, widget);
    } else {
      Navigator.pop(context);
    }
  }
}