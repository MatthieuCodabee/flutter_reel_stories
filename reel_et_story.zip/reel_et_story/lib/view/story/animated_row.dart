import 'package:flutter/material.dart';
import 'package:reel_et_story/view/story/animated_bar.dart';

import '../../model/story.dart';

class AnimatedRow extends StatelessWidget {
  final List<Story> stories;
  final AnimationController animationController;
  final int index;

  const AnimatedRow({
    super.key,
    required this.animationController,
    required this.stories,
    required this.index
  });

  @override
  Widget build(BuildContext context) {
    final map = stories.asMap();
    return Row(
      children: map.map((key, value) {
        return MapEntry(key, AnimatedBar(
            position: key,
            index: index,
            animationController: animationController)
        );
      }).values.toList(),
    );
  }
}