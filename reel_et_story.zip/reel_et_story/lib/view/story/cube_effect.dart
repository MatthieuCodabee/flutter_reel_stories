import 'dart:math';

import 'package:flutter/material.dart';

class CubeEffect extends PageRouteBuilder {
  final Duration duration;
  final Widget currentWidget;
  final Widget nextWidget;
  final Color backgroundColor;

  CubeEffect({
    required this.currentWidget,
    required this.nextWidget,
    this.backgroundColor = Colors.black,
    this.duration = const Duration(milliseconds: 500)
  }): super(
    transitionDuration: duration,
    pageBuilder: (context, animation, secondaryAnimation) => nextWidget,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      return Container(
        color: backgroundColor,
        child: Stack(
          children: [
            SlideTransition(
                position: Tween<Offset>(begin: Offset.zero, end: const Offset(-1, 0)).animate(animation),
              child: Transform(
                transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.003)
                    ..rotateY(pi / 2 * animation.value),
                alignment: FractionalOffset.centerRight,
                child: currentWidget,
              ),
            ),
            SlideTransition(
                position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero).animate(animation),
              child: Transform(
                transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.003)
                    ..rotateY(pi / 2 * (animation.value - 1)),
                alignment: FractionalOffset.centerLeft,
                child: nextWidget,
              ),
            )
          ],
        ),
      );
    }
  );

}