import 'package:flutter/material.dart';
import 'package:reel_et_story/data/test_data.dart';
import 'package:reel_et_story/view/reel/reel_page.dart';
import 'package:video_player/video_player.dart';

class ReelView extends StatefulWidget {
  const ReelView({super.key});

  @override
  ReelViewState createState() =>  ReelViewState();
}

class ReelViewState extends State<ReelView> {
  final PageController controller = PageController();
  VideoPlayerController? videoPlayerController;
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    loadVideo(currentIndex);
  }

  @override
  void dispose() {
    videoPlayerController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      controller: controller,
        scrollDirection: Axis.vertical,
        itemCount: reels.length,
        itemBuilder: (context, index) {
          return ReelPage(
              reel: reels[index],
              videoPlayerController: videoPlayerController,
              isVisible: (currentIndex == index)
          );
        },
      onPageChanged: loadVideo,
    );
  }

  loadVideo(int index) {
    videoPlayerController = null;
    videoPlayerController?.dispose();
    videoPlayerController = VideoPlayerController.networkUrl(Uri.parse(reels[index].url))
    ..initialize().then((value) => setState(() {
      if (videoPlayerController != null && videoPlayerController!.value.isInitialized) {
        videoPlayerController?.play();
        videoPlayerController?.setLooping(true);
        currentIndex = index;
      }
    }));

  }
}