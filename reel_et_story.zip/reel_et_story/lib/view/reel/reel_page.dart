import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:reel_et_story/model/reel.dart';
import 'package:video_player/video_player.dart';

class ReelPage extends StatelessWidget {
  final Reel reel;
  final VideoPlayerController? videoPlayerController;
  final bool isVisible;

  const ReelPage({
   super.key,
   required this.reel,
   required this.videoPlayerController,
   required this.isVisible
  });

  @override
  Widget build(BuildContext context) {
    return (!isVisible)
        ? Container(color: Colors.black)
        : Stack(
        children: [
          Align(
            alignment: Alignment.center,
            child: SizedBox(
              height: videoPlayerController?.value.size.height ?? 0,
              width: videoPlayerController?.value.size.width ?? 0,
              child: VideoPlayer(videoPlayerController!),
            ),
          ),
          Align(
            alignment: Alignment.bottomLeft,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 20,
                            backgroundColor: Colors.grey,
                            backgroundImage: CachedNetworkImageProvider(reel.user.imageUrl),
                          ),
                          const SizedBox(width: 12),
                          Text(reel.user.username)
                        ],
                      ),
                  ),
                  const Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.flash_on),
                      SizedBox(height: 16),
                      Icon(Icons.message),
                      SizedBox(height: 16),
                      Icon(Icons.share),
                      SizedBox(height: 24)
                    ],
                  )
                ],
              ),
            ),
          )
        ],
    );
  }
}