package com.example.reel_et_story

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
